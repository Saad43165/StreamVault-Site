'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft, Loader2, AlertTriangle, RefreshCw, List, Layers,
  ShieldCheck, ChevronRight, Monitor, Maximize,
} from 'lucide-react';
import { IFRAME_SANDBOX } from '@/lib/adblock';

interface StreamSource {
  provider: string;
  url: string;
  tier: string;
}

interface StreamData {
  success: boolean;
  type: string;
  totalSources: number;
  sources: StreamSource[];
  current: StreamSource;
}

interface TitleInfo {
  title: string;
  posterPath: string;
  backdropPath: string;
  totalEpisodes?: number;
}

export default function VideoPlayer({
  searchParams,
}: {
  searchParams: { id?: string; type?: string; season?: string; episode?: string };
}) {
  const [data, setData] = useState<StreamData | null>(null);
  const [title, setTitle] = useState<TitleInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [iframeLoading, setIframeLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sourceIndex, setSourceIndex] = useState(0);
  const [showSources, setShowSources] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [ready, setReady] = useState(false);

  const id = searchParams.id;
  const type = searchParams.type === 'tv' ? 'tv' : 'movie';
  const season = Number(searchParams.season) || 1;
  const episode = Number(searchParams.episode) || 1;

  const buildUrl = (idx: number) => {
    const base = `/api/stream?id=${id}&type=${type}`;
    if (type === 'tv') return `${base}&season=${season}&episode=${episode}&source=${idx}`;
    return `${base}&source=${idx}`;
  };

  const backHref = type === 'tv' ? `/tv/${id}` : `/movie/${id}`;

  const autoRotateTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch stream metadata when the source index changes.
  useEffect(() => {
    if (!id) {
      setError('No media ID provided.');
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    setReady(false);
    fetch(buildUrl(sourceIndex))
      .then((r) => {
        if (!r.ok) throw new Error('Failed to load stream');
        return r.json();
      })
      .then((d: StreamData) => {
        if (cancelled) return;
        setData(d);
        setLoading(false);
        setIframeLoading(true);
      })
      .catch(() => {
        if (cancelled) return;
        setError('We could not load this stream. Please try another source.');
        setLoading(false);
      });
    return () => {
      cancelled = true;
      if (autoRotateTimer.current) clearTimeout(autoRotateTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceIndex, id, type, season, episode]);

  // Fetch title info from the detail API for a richer player chrome.
  useEffect(() => {
    if (!id) return;
    fetch(`/api/details?id=${id}&type=${type}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((t: TitleInfo | null) => {
        if (t) setTitle(t);
      })
      .catch(() => {});
  }, [id, type]);

  // If the iframe hasn't signalled loaded in 12s, auto-rotate to next source.
  useEffect(() => {
    if (!iframeLoading || !data) return;
    autoRotateTimer.current = setTimeout(() => {
      setIframeLoading(false);
      setReady(true);
    }, 12000);
    return () => {
      if (autoRotateTimer.current) clearTimeout(autoRotateTimer.current);
    };
  }, [iframeLoading, data, sourceIndex]);

  // Auto-hide controls after inactivity.
  useEffect(() => {
    if (!ready) return;
    let hideTimer: ReturnType<typeof setTimeout>;
    const showAndHide = () => {
      setControlsVisible(true);
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => setControlsVisible(false), 3500);
    };
    showAndHide();
    const onMove = () => showAndHide();
    window.addEventListener('mousemove', onMove);
    window.addEventListener('touchstart', onMove, { passive: true });
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('touchstart', onMove);
      clearTimeout(hideTimer);
    };
  }, [ready]);

  const tryAnotherSource = useCallback(() => {
    if (!data) return;
    setSourceIndex((i) => (i + 1) % data.sources.length);
  }, [data]);

  // Keyboard shortcuts.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (document.fullscreenElement) document.exitFullscreen();
        else window.location.href = backHref;
      } else if (e.key === 'n' || e.key === 'N') {
        tryAnotherSource();
      } else if (e.key === 'f' || e.key === 'F') {
        const frame = document.getElementById('player-frame');
        if (!document.fullscreenElement) frame?.requestFullscreen?.();
        else document.exitFullscreen();
      } else if (e.key === 's' || e.key === 'S') {
        setShowSources((s) => !s);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [backHref, tryAnotherSource]);

  const handleIframeLoad = () => {
    setIframeLoading(false);
    setReady(true);
  };

  const enterFullscreen = () => {
    const frame = document.getElementById('player-frame');
    if (!document.fullscreenElement) frame?.requestFullscreen?.();
    else document.exitFullscreen();
  };

  const displayTitle = title?.title ?? (type === 'tv' ? `S${season}:E${episode}` : `Title #${id}`);
  const nextEpisodeHref =
    type === 'tv'
      ? `/watch?id=${id}&type=tv&season=${season}&episode=${episode + 1}`
      : null;

  const heroArt = title?.backdropPath
    ? `https://image.tmdb.org/t/p/original${title.backdropPath}`
    : null;

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col select-none">
      {/* Ambient backdrop art behind the iframe while loading */}
      {!ready && heroArt && (
        <div className="absolute inset-0 z-0">
          <img
            src={heroArt}
            alt=""
            className="w-full h-full object-cover opacity-30 blur-sm scale-105"
          />
          <div className="absolute inset-0 bg-black/60" />
        </div>
      )}

      {/* ── Top bar ───────────────────────────────────────── */}
      <div
        className={`absolute top-0 inset-x-0 z-30 flex items-center justify-between p-4 bg-gradient-to-b from-black/90 to-transparent transition-opacity duration-300 ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <Link
          href={backHref}
          className="inline-flex items-center gap-2 text-sm font-medium text-white/90 hover:text-white bg-black/40 backdrop-blur px-3 py-2 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>

        <div className="flex items-center gap-2">
          <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 backdrop-blur px-2.5 py-1.5 rounded-lg">
            <ShieldCheck className="w-3.5 h-3.5" />
            Ad-block
          </span>
          <button
            onClick={enterFullscreen}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-white/80 hover:text-white bg-black/40 backdrop-blur px-3 py-2 rounded-lg transition-colors"
            aria-label="Fullscreen"
          >
            <Maximize className="w-4 h-4" />
            <span className="hidden sm:inline">Fullscreen</span>
          </button>
          {data && (
            <div className="relative">
              <button
                onClick={() => setShowSources((s) => !s)}
                className="inline-flex items-center gap-2 text-sm font-medium text-white/80 hover:text-white bg-black/40 backdrop-blur px-3 py-2 rounded-lg transition-colors"
              >
                <Layers className="w-4 h-4" />
                <span className="hidden sm:inline">Sources</span>
                <span className="text-xs text-white/40">({sourceIndex + 1}/{data.totalSources})</span>
              </button>
              {showSources && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowSources(false)} />
                  <div className="absolute right-0 mt-2 z-20 min-w-[240px] max-h-[70vh] overflow-y-auto scrollbar-thin bg-vault-card border border-white/10 rounded-lg shadow-2xl overflow-hidden animate-fade-in">
                    {data.sources.map((s, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          setSourceIndex(i);
                          setShowSources(false);
                        }}
                        className={`w-full text-left px-4 py-2.5 text-sm hover:bg-white/5 transition-colors flex items-center justify-between ${
                          i === sourceIndex ? 'text-vault-accent bg-vault-accent/5' : 'text-white/80'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <List className="w-3.5 h-3.5" />
                          {s.provider}
                        </span>
                        <span className="text-[10px] text-white/40">{s.tier}</span>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Player area ───────────────────────────────────── */}
      <div className="flex-1 flex items-center justify-center relative" id="player-frame">
        {loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 z-20">
            <Loader2 className="w-12 h-12 text-vault-accent animate-spin" />
            <p className="text-white/60 text-sm">Preparing your stream...</p>
          </div>
        )}

        {error && !loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 text-center px-4 animate-fade-in z-20">
            <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
              <AlertTriangle className="w-8 h-8 text-red-400" />
            </div>
            <h2 className="text-xl font-bold">Playback error</h2>
            <p className="text-white/50 max-w-md">{error}</p>
            <div className="flex items-center gap-3">
              {data && (
                <button
                  onClick={tryAnotherSource}
                  className="inline-flex items-center gap-2 bg-vault-accent hover:bg-vault-accent-hover text-white font-semibold px-5 py-2.5 rounded-lg transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  Try another source
                </button>
              )}
              <Link
                href={backHref}
                className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-5 py-2.5 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Go back
              </Link>
            </div>
          </div>
        )}

        {!loading && !error && data && (
          <div className="w-full h-full relative bg-black">
            {iframeLoading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 z-10 pointer-events-none">
                <Loader2 className="w-12 h-12 text-vault-accent animate-spin" />
                <p className="text-white/70 text-sm font-medium">
                  Loading {data.current.provider}...
                </p>
                <p className="text-white/40 text-xs">
                  If video doesn&apos;t appear, switch sources (press <kbd className="px-1.5 py-0.5 bg-white/10 rounded text-[10px]">S</kbd>)
                </p>
              </div>
            )}
            <iframe
              key={data.current.url}
              src={data.current.url}
              title={data.current.provider}
              className="w-full h-full border-0"
              allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
              sandbox={IFRAME_SANDBOX}
              referrerPolicy="origin"
              allowFullScreen
              onLoad={handleIframeLoad}
            />
          </div>
        )}
      </div>

      {/* ── Bottom bar (now playing + next episode) ────────── */}
      {!loading && !error && data && (
        <div
          className={`absolute bottom-0 inset-x-0 z-30 p-4 bg-gradient-to-t from-black/90 via-black/50 to-transparent transition-opacity duration-300 ${
            controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {title?.posterPath ? (
                <img
                  src={`https://image.tmdb.org/t/p/w92${title.posterPath}`}
                  alt=""
                  className="w-10 h-14 rounded object-cover shrink-0 hidden sm:block"
                />
              ) : null}
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">{displayTitle}</p>
                <p className="text-xs text-white/50 truncate">
                  <span className="text-vault-accent">{data.current.provider}</span>
                  <span className="mx-1.5 text-white/20">·</span>
                  {data.current.tier}
                  {type === 'tv' && (
                    <>
                      <span className="mx-1.5 text-white/20">·</span>
                      S{season}:E{episode}
                    </>
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {nextEpisodeHref && (
                <Link
                  href={nextEpisodeHref}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-vault-accent hover:bg-vault-accent-hover px-3 py-2 rounded-lg transition-colors"
                >
                  Next Episode
                  <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              )}
              <button
                onClick={tryAnotherSource}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-white/70 hover:text-white bg-black/40 backdrop-blur px-3 py-2 rounded-lg transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Next source
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
